package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class IncidentSearchPage extends ProjectSpecificMethods{
	
	public IncidentSearchPage(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public IncidentSearchPage enterSearchText(String data) {
		driver.switchTo().frame("gsft_main");
		WebElement ele = driver.findElement(By.xpath("//button[text()='New']/following::span[text()='Search']/following::input"));
		ele.sendKeys(data,Keys.ENTER);
		
		return this;
	}
	
	public IncidentSearchPage verifySearchResult(String data) {
		boolean displayed = driver.findElement(By.linkText(data)).isDisplayed();
		if(displayed) {
			System.out.println("Pass");
		}
		else {
			System.out.println("Fail");
		}
		return this;
	}

}
