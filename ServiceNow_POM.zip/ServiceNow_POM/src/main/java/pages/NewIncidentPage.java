package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class NewIncidentPage extends ProjectSpecificMethods{
	
	public NewIncidentPage(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public NewIncidentPage getIncidentNumber() {
		
		incidentNumber = driver.findElement(By.id("incident.number")).getAttribute("value");
		return this;
	}
	
	public NewIncidentPage selectCaller(String data) throws InterruptedException {
		driver.switchTo().frame("gsft_main");
		WebElement ele = driver.findElement(By.id("sys_display.incident.caller_id"));
		ele.sendKeys("abel");
		Thread.sleep(2000);
		ele.sendKeys(Keys.TAB);
		
		return this;
	}
	
	public NewIncidentPage enterShortDescription(String data) {
		driver.findElement(By.id("incident.short_description")).sendKeys(data);
		return this;
	}
	
	public IncidentSearchPage clickSubmit() {
		driver.findElement(By.xpath("//button[text()='Submit']")).click();
		driver.switchTo().defaultContent();
		return new IncidentSearchPage(driver);
	}

}
