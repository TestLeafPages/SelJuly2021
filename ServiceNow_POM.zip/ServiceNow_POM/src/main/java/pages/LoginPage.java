package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
	}

	public LoginPage enterUsername(String uName) {
		driver.switchTo().frame(0);
		driver.findElement(By.id("user_name")).sendKeys(uName);

		return this;
	}

	public LoginPage enterPassword(String pWord) {

		driver.findElement(By.id("user_password")).sendKeys(pWord);

		return this;
	}

	public HomePage clickLoginButton() {

		driver.findElement(By.id("sysverb_login")).click();
		driver.switchTo().defaultContent();
		return new HomePage(driver);
	}

}
