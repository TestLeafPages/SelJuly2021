package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	public HomePage(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public HomePage searchFilterText(String searchText) {
		driver.findElement(By.id("filter")).sendKeys(searchText);
		return this;
	}

	
	
	public NewIncidentPage clickCreateNew() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[text()='Create New'])[1]")).click();
		return new NewIncidentPage(driver);
	}
	

}
