package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class CreateIncident extends ProjectSpecificMethods {
	
	@Test
	public void runCreateIncident() throws InterruptedException {
		new LoginPage(driver)
		.enterUsername("admin")
		.enterPassword("India@123")
		.clickLoginButton()
		.searchFilterText("incident")
		.clickCreateNew()
		.selectCaller("abel")
		.enterShortDescription("testing")
		.getIncidentNumber()
		.clickSubmit()
		.enterSearchText(incidentNumber)
		.verifySearchResult(incidentNumber);
		

	}

}
