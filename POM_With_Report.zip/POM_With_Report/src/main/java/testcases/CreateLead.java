package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		excelFileName = "CreateLead";
		testName = "CreateLead";
		testDescription = "CreateLead with manadatory information";
		testCategory = "Functional";
		testAuthor = "Hari";

	}

	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String username, String password, String company, String firstName, String lastName) throws InterruptedException, IOException {
		System.out.println(driver);
		
		new LoginPage(driver)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.enterCompanyName(company)
		.clickCreateLeadButton()
		.verifyFirstName(firstName);

	}

}
