package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		excelFileName = "Login";
		testName = "Login Verifcation";
		testDescription = "Login with positive data and verify";
		testCategory = "Smoke";
		testAuthor = "Hari";

	}
	
	@Test(dataProvider = "fetchData")
	public void runLoginTest(String username,String password) throws InterruptedException, IOException {
		
		//LoginPage lp = new LoginPage();
		
		new LoginPage(driver)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton();
	//	.clickLogoutButton();

	}

}
