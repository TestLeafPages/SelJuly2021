package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods {

	public ViewLeadPage(ChromeDriver driver) {
		this.driver = driver;

	}

	public ViewLeadPage verifyFirstName(String expValue) {
		//boolean displayed = driver.findElement(By.id("viewLead_firstName_sp")).isDisplayed();
		//Assert.assertTrue(displayed);
		
		String actValue = driver.findElement(By.id("viewLead_firstName_sp")).getText();
		Assert.assertEquals(actValue, expValue);
		return this;
	}

}
