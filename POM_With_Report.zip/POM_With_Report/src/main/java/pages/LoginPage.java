package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
		
	}
					//actionElementName
	public LoginPage enterUsername(String uName) throws InterruptedException, IOException {
		WebElement ele = locateElement("id", "username");
		type(ele, uName);
		
		return this;
	}
	
	public LoginPage enterPassword(String pWord) throws IOException {
		WebElement ele = locateElement("id", "password");
		type(ele, pWord);
		return this;
	}
	
	public HomePage clickLoginButton() throws IOException {
		click(locateElement("class", "decorativeSubmit"));
		return new HomePage(driver);
	}

}
