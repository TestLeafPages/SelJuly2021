package base;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import utils.Reporter;

//library / Wrapper
public class SeleniumBase extends Reporter {
	
	
	
	//locator & locatorValue
	public WebElement locateElement(String locator, String value) throws IOException {
		
		try {
			switch (locator) {
			case "id": return driver.findElement(By.id(value));
			case "name": return driver.findElement(By.name(value));
			case "class": return driver.findElement(By.className(value));
			case "xpath": return driver.findElement(By.xpath(value));
			
			}
			reportStep("Element is located succcessfully","pass");
		} catch (Exception e) {
			reportStep("Element is not located succcessfully","fail");
		}
		return null;
	}
	
	//WebElement & data
	public void type(WebElement ele, String data) throws IOException {
		try {
			ele.sendKeys(data);
			reportStep("Data entered succcessfully","pass");
		} catch (Exception e) {
			reportStep("Data not entered succcessfully","fail");
		}
		
	}
	
	//WebElement
	public void click(WebElement ele) throws IOException {
		try {
			ele.click();
			reportStep("element is clicked succcessfully","pass");
		} catch (Exception e) {
			reportStep("element is not clicked succcessfully","fail");
		}

	}
	
	public int takeSnap() throws IOException {
		int ranNum = (int) (Math.random()*99999);
		File source = driver.getScreenshotAs(OutputType.FILE);
		File target = new File("./snaps/img"+ranNum+".png");
		FileUtils.copyFile(source, target);
		return ranNum;
	}

}
