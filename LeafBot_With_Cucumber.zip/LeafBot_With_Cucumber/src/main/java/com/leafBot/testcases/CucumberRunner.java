package com.leafBot.testcases;

import org.testng.annotations.BeforeTest;

import com.leafBot.testng.api.base.ProjectSpecificMethods;

import io.cucumber.testng.CucumberOptions;



@CucumberOptions(features="src/main/java/features", glue="com.leafBot.pages", monochrome=true)
public class CucumberRunner extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setValues() {
		testCaseName = "Login and Verify";
		testDescription = "Login testCase using positive data from feature file";
		nodes = "Leads";
		authors = "Hari";
		category = "Smoke";
		
	}

}
