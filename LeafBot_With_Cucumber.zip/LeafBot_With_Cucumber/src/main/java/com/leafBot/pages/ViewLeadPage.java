package com.leafBot.pages;

import com.leafBot.testng.api.base.ProjectSpecificMethods;



public class ViewLeadPage extends ProjectSpecificMethods  {

	
	
	public ViewLeadPage verifyFirstName(String fname) {
		verifyPartialText(locateElement("id","viewLead_firstName_sp"), fname);
		return this;
	}
	
	
	public FindLeadPage clickFindLead(){
		click(locateElement("link","Find Leads"));
		return new FindLeadPage();
	}
	
	
	public ViewLeadPage verifyCompanyName(String CompanyName) {
		verifyPartialText(locateElement("id","viewLead_companyName_sp"), CompanyName);
		return this;
	}
	
	public EditLeadPage clickEditLeadLink(){
		click(locateElement("link","Edit"));
		return new EditLeadPage();
	}
	
	public DuplicateLeadPage clickDuplicateLeadLink(){
		click(locateElement("link","Duplicate Lead"));
		return new DuplicateLeadPage();
	}
	
	public MyLeadsPage clickDeleteLeadLink(){
		click(locateElement("link","Delete"));
		return new MyLeadsPage();
	}
	
	

	
	
}
