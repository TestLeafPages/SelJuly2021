package com.leafBot.pages;

import com.leafBot.testng.api.base.ProjectSpecificMethods;



public class DuplicateLeadPage extends ProjectSpecificMethods {


	public ViewLeadPage clickCreateLeadDublicate(){
		click(locateElement("class","smallSubmit"));
		return new ViewLeadPage();
	}
}
