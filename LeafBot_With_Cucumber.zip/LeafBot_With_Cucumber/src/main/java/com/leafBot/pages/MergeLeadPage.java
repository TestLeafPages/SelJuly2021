package com.leafBot.pages;

import com.leafBot.testng.api.base.ProjectSpecificMethods;



public class MergeLeadPage extends ProjectSpecificMethods {


	
	public FindLeadPopPage clickFromLeadLookup(){
		clickWithNoSnap(locateElement("xpath","(//img[@alt='Lookup'])[1]"));
		switchToWindow(1);
		return new FindLeadPopPage();		
	}

	
	public FindLeadPopPage clickToLeadLookup(){
		clickWithNoSnap(locateElement("xpath","(//img[@alt='Lookup'])[2]"));
		switchToWindow(1);
		return new FindLeadPopPage();		
	}

	
	public ViewLeadPage clickMergeButton(){
		clickWithNoSnap(locateElement("link","Merge"));
		acceptAlert();
		return new ViewLeadPage();
	}
}