package com.leafBot.pages;

import com.leafBot.testng.api.base.ProjectSpecificMethods;



public class MyLeadsPage extends ProjectSpecificMethods {

	// Click Create Leads 
	public CreateLeadPage clickCreateLead(){
		click(locateElement("link","Create Lead"));
		return new CreateLeadPage();
	}

	
	
	public FindLeadPage clickFindLead(){
		click(locateElement("link","Find Leads"));	
		return new FindLeadPage();
	}
	
	
	
	public MergeLeadPage clickMergeLead(){
		click(locateElement("link","Merge Leads"));	
		return new MergeLeadPage();
	}
	
	

}
