package com.leafBot.pages;

import com.leafBot.testng.api.base.ProjectSpecificMethods;

import io.cucumber.java.en.Then;


public class HomePage extends ProjectSpecificMethods{

	
	public HomePage verifyLoggedName(String data) {
		verifyPartialText(locateElement("xpath","//h2[text()[contains(.,'Demo')]]"), data);
		return this;
	}

	

	public MyHomePage clickCRMSFA(){
		click(locateElement("link","CRM/SFA"));
		return new MyHomePage();
	}

	
	
	public LoginPage clickLogout() {
		click(locateElement("class","decorativeSubmit"));
		return new LoginPage();

	}
	
	@Then("Homepage should be displayed")
	public HomePage verifyHomepage() {
		verifyDisplayed(locateElement("link","CRM/SFA"));
		return this;
	}

}










